package Game;

/**
 * Abstract class representing games
 */
public abstract class Game {

    public Game(){

    }
}
