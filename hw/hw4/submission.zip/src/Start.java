import Game.Legends;

public class Start {
    public static void main(String[] args) {
        Legends legends = new Legends();
        legends.start();
     }
}
