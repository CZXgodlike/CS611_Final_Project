package Monsters;

import java.util.List;

/**
 * Class represents a Dragon
 */
public class Dragon extends Monster{

    public Dragon(List<String> list){
        super(list);
    }

    public Dragon(){}
}
