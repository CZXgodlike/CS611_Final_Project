package Monsters;

import java.util.List;

/**
 * Class represents a spirit
 */
public class Spirit extends Monster{

    public Spirit(){super();}

    public Spirit(List<String> list){
        super(list);
    }
}
